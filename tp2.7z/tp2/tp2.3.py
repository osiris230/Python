def convertir_en_celsius():
    
    f = int(input("Entrez une température en fahrenheit: "))
    
    c = (f-32) * 9/5
    
    return c

print(f"Voici le résultat en celsius {convertir_en_celsius()}.")