def est_pair():

    a = int(input("Entrez un nombre : "))
    
    return a % 2 == 0

print(est_pair())
