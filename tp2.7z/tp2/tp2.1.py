def somme():
    
    a = int(input("Entrez le premier nombre : "))
    
    b = int(input("Entrez le deuxième nombre : "))
    
    return a + b

print(f"La somme des deux nombres est {somme()}.")