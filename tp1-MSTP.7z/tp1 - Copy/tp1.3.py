for x in range(11):
  print(x) 

nombre = 1


while nombre <= 5:
    carre = nombre ** 2
    print("Le carré de", nombre, "est ", carre)
    nombre += 1