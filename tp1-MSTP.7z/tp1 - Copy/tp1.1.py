print("Bonjour, monde!")
nom = ("Maxime")
print("Salut", nom,"!")