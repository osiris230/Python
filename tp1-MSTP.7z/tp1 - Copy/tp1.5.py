def calculer_moyenne(nombres):
    if not nombres:
        return 0
    somme = sum(nombres)
    
    moyenne = somme / len(nombres)
    
    return moyenne

nombres = [4, 8, 15, 16, 23, 42]
moyenne = calculer_moyenne(nombres)
print("La moyenne des nombres", nombres, "est", moyenne)